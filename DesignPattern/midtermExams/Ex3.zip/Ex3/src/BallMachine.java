
public class BallMachine {

	final static int SOLD_OUT = 0; //매진 상태
	final static int NO_COIN = 1;  //동전 없음 상태
	final static int HAS_COIN = 2; //동전 있음 상태
	final static int SOLD = 3; //판매 중 상태
	
	int state = SOLD_OUT; //현재 상태를 표시하는 변수
	int count = 0; //볼의 갯수
	
	//초기 볼의 갯수를 인자로 받아들이는 생성자.
	
	public BallMachine(int count) {
		this.count = count;
		
		if (count > 0) {
			state = NO_COIN;
		}
	}
	
	//동전이 투입되는 경우
	public void insertCoin() {
		if (state == HAS_COIN) {}
		else if (state == NO_COIN) {
			state = HAS_COIN;
		}
		else if (state == SOLD_OUT) {}
		else if (state == SOLD) {}
	}
	
	//동전을 반환하는 경우 
	public void ejectCoin() {
		if (state == HAS_COIN) {
			state = NO_COIN;
		}
		else if (state == NO_COIN) {}
		else if (state == SOLD_OUT) {}
		else if (state == SOLD) {}
	}
	
	//손잡이를 돌리는 경우
	public void turnCrank() {
		if (state == HAS_COIN) {
			state = SOLD;
			dispense();
		}
		else if (state == NO_COIN) {}
		else if (state == SOLD_OUT) {}
		else if (state == SOLD) {}
	}
	
	//볼 내보내기
	public void dispense() {
		if (state == HAS_COIN) {}
		else if (state == NO_COIN) {}
		else if (state == SOLD_OUT) {}
		else if (state == SOLD) {
			count = count -1;
			if (count == 0) {
				state = SOLD_OUT;
			}
			else state = NO_COIN;
		}
	}

	@Override
	public String toString() {
		return "BallMachine [state=" + state + ", count=" + count + "]";
	}
	
		
}
