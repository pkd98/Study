import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;

public class CartForSongs {
	
	ArrayList<Song> cart = new ArrayList<Song>();
	public double calculateTotalPrice() {
		
		double total = 0.0;
		Iterator <Song> i = cart.iterator(); //장바구니 이터레이터
		
		while (i.hasNext()) { //장바구니 전체 노래 가격 계산
			Song s = i.next();
			total = total +s.getPrice();
		}
		return total;
	}
	
	public void add(Song s) {
		cart.add(s);
	}
}