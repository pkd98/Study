
public class NonDiscounted extends DiscountedMode {

	@Override
	public double getDiscountRate() {
		// TODO Auto-generated method stub
		return 0.0;
	}
}
