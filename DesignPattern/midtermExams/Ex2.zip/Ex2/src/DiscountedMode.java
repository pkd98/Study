
public abstract class DiscountedMode {
	public double getDiscountRate() {
		return 0;
	}
}
