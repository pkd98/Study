
public class TodayEvent extends DiscountedMode {

	@Override
	public double getDiscountRate() {
		// TODO Auto-generated method stub
		return 0.3;
	}

}
