
public class Song {
	private DiscountedMode mode;
	public void setMode(DiscountedMode mode) {
		this.mode = mode; //해당 모드 넣음
	}
	
	public double getPrice() { // 가격 리턴
		//기본 10.0에 할인된 가격 뺌 -> 그게 그 가격
		return 10.0-(10.0*this.mode.getDiscountRate());
	}
}