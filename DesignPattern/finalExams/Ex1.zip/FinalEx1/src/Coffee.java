
public class Coffee extends CaffeineBeverage {
	
	public void brew() {
		System.out.println("coffee filtering..");
	}
	public void addCondiments() {
		System.out.println("sugar and milk adding..");
	}
}
