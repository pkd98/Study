//printers to be used
//System.out.println("water boiling..");
//System.out.println("cup pouring..");

public abstract class CaffeineBeverage {
	//Write your code here.. 
	final void prepareRecipe() {
		boilWater();
		brew();
		pourInCup();
		addCondiments();
	}
	
	abstract void brew();
	abstract void addCondiments();
	void boilWater() {
		System.out.println("water boiling..");
	}
	void pourInCup() {
		System.out.println("cup pouring..");
	}
	
}
