
public class Tea extends CaffeineBeverage {
	
	public void brew() {
		System.out.println("tea brewing..");
	}
	public void addCondiments() {
		System.out.println("lemon adding..");
	}
	
}
