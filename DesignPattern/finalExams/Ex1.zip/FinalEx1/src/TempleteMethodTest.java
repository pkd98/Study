
public class TempleteMethodTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tea myTea = new Tea(); 
		myTea.prepareRecipe(); 
		
		System.out.println("-------------------------------");
		
		Coffee myCoffee = new Coffee();
		myCoffee.prepareRecipe();
	}

}
