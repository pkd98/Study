import java.util.ArrayList;
import java.util.List;

public class Subject {
	//write your code here..
	//옵저버 리스트
	private List<Observer> observers = new ArrayList<Observer>();
	//옵저버 등록
	public void attach(Observer o) {
		observers.add(o);
	}
	
	//옵저버 제거
	public void detach(Observer o) {
		observers.remove(o);
	}
	
	//옵저버 변경 내역 알리기
	public void notifyObservers() {
		for (int i=0; i<observers.size(); i++) {
			Observer o = observers.get(i);
			o.update();
		}
	}

}
