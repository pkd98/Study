//printers to be used..
//System.out.println("Warning: LOW battery: " + level +  " compared with " + LOW_BATTERY);
//level is a variance to get the current Level of the battery

public class LowBatteryWarning implements Observer {
	//write your code here..
	private Battery battery;

	public LowBatteryWarning(Battery battery) {
		this.battery = battery;
	}
	
	public void update() {
		int level = battery.getLevel();
		int LOW_BATTERY = 30;
		if(level < LOW_BATTERY)
			System.out.println("Warning: LOW battery: " + level +  " compared with " + LOW_BATTERY);
	}
}
