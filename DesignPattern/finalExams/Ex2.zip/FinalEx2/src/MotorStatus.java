public enum MotorStatus {STOPPED, MOVING }
