
public abstract class ElevatorFactory {
	//write your code here..
	abstract public Motor createMotor();	
	abstract public Door createDoor();
	
}