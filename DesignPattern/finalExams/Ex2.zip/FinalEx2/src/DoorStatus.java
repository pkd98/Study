
public enum DoorStatus {
	OPENED, CLOSED
}
