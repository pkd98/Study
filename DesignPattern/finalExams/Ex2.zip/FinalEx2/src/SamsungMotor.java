//System.out.println("move Samsung motor");

public class SamsungMotor extends Motor {
	//write your code here..
	protected void moveMotor(Direction direction) {
		System.out.println("move Samsung motor");
	}
}
