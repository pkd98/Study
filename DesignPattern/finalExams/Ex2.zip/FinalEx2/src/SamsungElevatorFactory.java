
public class SamsungElevatorFactory extends ElevatorFactory {
	//write your code here..
	public Motor createMotor() {
		return new SamsungMotor();
	}
	public Door createDoor() {
		return new SamsungDoor();
	}
}
