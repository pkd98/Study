//printers to be used 
//System.out.println("close Samsung Door");
//System.out.println("open Samsung Door");

public class SamsungDoor extends Door {
	//write your code here..
	protected void doClose() {
		System.out.println("close Samsung Door");		
	}
	protected void doOpen() {
		System.out.println("open Samsung Door");
	}
}

